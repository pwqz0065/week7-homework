class Dog:
    def __init__(self, name):
        self.name = name

    def bark():
        print("Woof! My name is", self.name)
