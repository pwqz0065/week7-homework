class Point:
    def __init__(self, x, y):
        self.x = x

    def display(self):
        print("Point at:", self.x, self.y)
