class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return radius * radius * 3.1415
